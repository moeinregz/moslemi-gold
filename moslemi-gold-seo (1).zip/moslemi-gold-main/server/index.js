import express from "express";
import fs from "node:fs";
import path from "node:path";
import { ROOT, PORT, IS_PROD, siteUrl } from "./config.js";
import { db, UPLOAD_DIR } from "./db.js";
import { getSettings } from "./settings.js";
import { getPublic } from "./catalog.js";
import publicApi from "./routes/public.js";
import adminApi from "./routes/admin.js";
import feeds from "./channels/feeds.js";

db(); // ساخت/مهاجرت دیتابیس هنگام شروع

export const app = express();
app.disable("x-powered-by");
if (process.env.TRUST_PROXY) app.set("trust proxy", Number(process.env.TRUST_PROXY) || true);

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  next();
});
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));

// محافظت CSRF: درخواست‌های تغییردهنده به API باید از fetch خود سایت بیان (هدر سفارشی).
// بازگشت درگاه پرداخت استثناست چون از سایت بانک POST می‌شه.
app.use("/api", (req, res, next) => {
  if (req.method === "GET" || req.method === "HEAD" || req.path.startsWith("/payment/callback/")) return next();
  if (req.get("x-requested-with") !== "fetch") return res.status(403).json({ error: "درخواست نامعتبر" });
  next();
});

app.use("/uploads", express.static(UPLOAD_DIR, { maxAge: "30d", immutable: true, fallthrough: false }));
app.use("/api/admin", (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
}, adminApi);
app.use("/api", publicApi);
app.use("/api", (req, res) => res.status(404).json({ error: "مسیر پیدا نشد." }));
app.use(feeds);

// ---------------- صفحات React ----------------
const DIST = path.join(ROOT, "dist");
const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/**
 * متاتگ‌ها سمت سرور به HTML اضافه می‌شن تا ترب، گوگل و شبکه‌های اجتماعی بدون اجرای جاوااسکریپت
 * عنوان، قیمت و موجودی هر محصول رو ببینن.
 */
function headFor(req) {
  const s = getSettings();
  const base = siteUrl();
  const m = req.path.match(/^\/product\/([^/]+)\/?$/);
  if (m) {
    const p = getPublic(decodeURIComponent(m[1]));
    if (p) {
      const url = `${base}/product/${encodeURIComponent(p.slug)}`;
      const img = p.images[0] ? base + p.images[0].url : "";
      const desc = p.short_desc || `${p.title} - طلای ${p.karat} عیار، ${p.weight} گرم`;
      const ld = {
        "@context": "https://schema.org", "@type": "Product", name: p.title, sku: p.sku || String(p.id), description: desc,
        image: p.images.map((i) => base + i.url), brand: { "@type": "Brand", name: s.store_name },
        offers: { "@type": "Offer", url, priceCurrency: "IRR", price: p.price * 10, availability: `https://schema.org/${p.in_stock ? "InStock" : "OutOfStock"}` },
      };
      return { status: 200, head: `<title>${esc(p.title)} | ${esc(s.store_name)}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${esc(url)}">
<meta property="og:type" content="product"><meta property="og:title" content="${esc(p.title)}"><meta property="og:url" content="${esc(url)}">
${img ? `<meta property="og:image" content="${esc(img)}">` : ""}
<meta name="product_id" content="${p.id}">
<meta name="product_name" content="${esc(p.title)}">
<meta name="product_price" content="${p.in_stock ? p.price : 0}">
<meta name="product_old_price" content="${p.old_price || ""}">
<meta name="availability" content="${p.in_stock ? "instock" : "outofstock"}">
<meta name="guarantee" content="${esc(p.guarantee)}">
<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, "\\u003c")}</script>` };
    }
    return { status: 404, head: `<title>محصول پیدا نشد | ${esc(s.store_name)}</title><meta name="robots" content="noindex">` };
  }
  if (req.path === "/") {
    const kw = s.seo_keyword || "طلافروشی مسلمی ملارد";
    const title = `${kw} | خرید آنلاین طلا و جواهر با عیار تضمینی`;
    const desc = `${kw}؛ خرید طلا و جواهر با عیار تضمینی، قیمت به نرخ روز و ضمانت بازخرید. شهرک ارم، جاده ملارد. خرید آنلاین و حضوری.`;
    const tel = "+98" + String(s.store_phone || "").replace(/[۰-۹]/g, (c) => "۰۱۲۳۴۵۶۷۸۹".indexOf(c)).replace(/^0/, "");
    const ld = {
      "@context": "https://schema.org",
      "@graph": [
        { "@type": "WebSite", name: kw, url: `${base}/`, inLanguage: "fa" },
        {
          "@type": "JewelryStore", name: kw, alternateName: s.store_name, url: `${base}/`, telephone: tel,
          description: desc, priceRange: "$$",
          address: { "@type": "PostalAddress", streetAddress: s.store_address, addressLocality: "کرج", addressRegion: "البرز", addressCountry: "IR" },
          areaServed: ["ملارد", "کرج", "شهریار"],
        },
      ],
    };
    return { status: 200, head: `<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${esc(base + "/")}">
<meta property="og:type" content="website"><meta property="og:locale" content="fa_IR"><meta property="og:site_name" content="${esc(kw)}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${esc(base + "/")}">
<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, "\\u003c")}</script>` };
  }
  const noindex = /^\/(admin|checkout|account|cart|order|pay)/.test(req.path) ? `<meta name="robots" content="noindex">` : "";
  return { status: 200, head: `<title>${esc(s.store_name)} | ${esc(s.store_tagline)}</title>
<meta name="description" content="${esc(`${s.store_name}؛ فروش آنلاین طلا و جواهر با عیار تضمینی، قیمت به نرخ روز و ضمانت بازخرید.`)}">
<meta property="og:title" content="${esc(s.store_name)}">${noindex}` };
}

if (IS_PROD || fs.existsSync(path.join(DIST, "index.html"))) {
  // قالب HTML با هر build جدید دوباره خونده می‌شه (بدون نیاز به ری‌استارت)
  let cache = { mtime: 0, html: "" };
  const template = () => {
    const file = path.join(DIST, "index.html");
    const m = fs.statSync(file).mtimeMs;
    if (m !== cache.mtime) cache = { mtime: m, html: fs.readFileSync(file, "utf8") };
    return cache.html;
  };
  app.use("/assets", express.static(path.join(DIST, "assets"), { maxAge: "1y", immutable: true, fallthrough: false }));
  app.use(express.static(DIST, { index: false, maxAge: "1d" }));
  app.get("*", (req, res) => {
    res.setHeader("Cache-Control", "no-cache");
    const html = template();
    const { status, head } = headFor(req);
    res.status(status).type("html").send(html.replace("<!--app-head-->", head));
  });
} else {
  app.get("/", (req, res) => res.send("API در حال اجراست. برای رابط کاربری: npm run dev (پورت 5173) یا npm run build."));
}

app.use((err, req, res, next) => {
  if (err.status === 404 || err.statusCode === 404) return res.status(404).end();
  console.error(err);
  res.status(500).json({ error: "خطای داخلی سرور" });
});

if (process.argv[1] && path.resolve(process.argv[1]) === path.join(ROOT, "server", "index.js")) {
  app.listen(PORT, () => console.log(`✓ ${getSettings().store_name} روی http://localhost:${PORT}  (SITE_URL=${siteUrl()})`));
}
